TAPPY PRESS KIT
https://www.tappy.net/press/

Thanks for writing about Tappy! Everything in this folder is free to use in
editorial coverage, reviews, and features about Tappy.


ABOUT TAPPY

Short:
Tappy is a self-care pet and fidget app for iPhone and Apple Watch that levels
up as you destress, stay focused, and build a routine that's all yours.

Long:
Tappy is a self-care pet who grows with you. Build a Daily Adventure from 25+
self-care quests, take care of Tappy, and collect Sparks to unlock outfits,
scenes, and surprises. Along the way, Tappy offers 25+ haptic fidgets, 9
breathing exercises, guided meditations, 40+ audio-haptic Feelscapes, a mood
journal, habit tracker, planner, goals, a focus timer, and 14+ arcade games.
Tappy is free on the App Store for iPhone and Apple Watch, with an optional
Tappy Plus subscription. Journal entries stay on your device and in your own
iCloud, with no accounts, no ads, and no tracking. Tappy is made by Pacific
Interactive LLC in California.


FACT SHEET

Developer      Pacific Interactive LLC
Based in       California, USA
Platforms      iPhone and Apple Watch
Price          Free, with optional Tappy Plus
Latest version Tappy 6.0
Downloads      1,000,000+
Rating         4.8 stars from 20,000+ App Store ratings
App Store      https://apps.apple.com/us/app/tappy-self-care-pet-fidget/id1492017640
Website        https://www.tappy.net


WHAT'S INSIDE

Logos/
  tappy-logo.png          Full logo for light backgrounds (2500 x 1050)
  tappy-logo-white.png    Full logo for dark backgrounds (2500 x 1050)
  tappy-icon-mark.png     Tappy face mark, transparent (2500 x 2500)
App Icon/
  tappy-app-icon.png          App Store icon, square (1024 x 1024)
  tappy-app-icon-rounded.png  App icon with rounded corners (1024 x 1024)
Screenshots/
  Eight Tappy 6.0 App Store screenshots (1242 x 2688)
Artwork/
  tappy-banner.png        Banner artwork (3840 x 1646)
  tappy-and-friends.png   Tappy with friends, transparent (2000 x 1477)
  tappy-wave.png/.svg       Tappy waving, transparent PNG (~1900px) and SVG
  tappy-cheer.png/.svg      Tappy cheering, transparent PNG (~1900px) and SVG
  tappy-companion.png/.svg  Tappy smiling, transparent PNG (~1900px) and SVG
  tappy-curious.png/.svg    Tappy curious, transparent PNG (~1900px) and SVG


BRAND COLORS

Tappy Blue   HEX #3ED5FF   RGB 62, 213, 255
Deep Sea     HEX #004259   RGB 0, 66, 89
Ink          HEX #15334A   RGB 21, 51, 74
Sunshine     HEX #FFD84D   RGB 255, 216, 77
Cream        HEX #FFF6E4   RGB 255, 246, 228


USING THE LOGO

- Use tappy-logo.png on light backgrounds and tappy-logo-white.png on dark ones.
- Leave clear space around the logo at least as wide as the "T" in Tappy.
- Please don't stretch, rotate, recolor, outline, or add effects to the logo.
- Please don't redraw the logo or combine it with other logos.
- Write the name as "Tappy" (capital T). The full App Store title is
  "Tappy: Self Care Pet & Fidget".

Tappy and the Tappy logo are trademarks of Pacific Interactive LLC.


PRESS CONTACT

cameron@pacific.dev
